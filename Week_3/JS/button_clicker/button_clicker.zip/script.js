function switchLogout(element) {
    element.innerText = "Logout";
}

function hide(element) {
    element.remove();
}