console.log("page loaded...");

let first = document.getElementById("first-request")
let second = document.getElementById("second-request")
let edit = document.getElementById("edit-name")

function changeRequest(element) {
    element.remove();
}

function changeName() {
    console.log("button pressed");
    edit.innerText = "Brendan Angelo";
}