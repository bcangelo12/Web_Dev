console.log("page loaded...")

let first = document.querySelector("#likesNumber-1");
let num1 = first.innerText
console.log(num1)

let second = document.querySelector("#likesNumber-2");
let num2 = second.innerText
console.log(num2)

let third = document.querySelector("#likesNumber-3");
let num3 = third.innerText
console.log(num3)

function likeFirst() {
    console.log('button pressed')
    num1++
    first.innerText = num1
}

function likeSecond() {
    console.log('button pressed')
    num2++
    second.innerText = num2
}

function likeThird() {
    console.log('button pressed')
    num3++
    third.innerText = num3
}